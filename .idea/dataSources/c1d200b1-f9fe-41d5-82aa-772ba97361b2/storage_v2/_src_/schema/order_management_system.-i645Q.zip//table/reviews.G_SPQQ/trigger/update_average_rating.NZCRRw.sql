create definer = root@localhost trigger update_average_rating
    after insert
    on reviews
    for each row
BEGIN
UPDATE products AS p
INNER JOIN (
    SELECT productId, AVG(rating) AS avg_rating
    FROM reviews
    GROUP BY productId
) AS r ON p.prodId = r.productId
SET p.avgRating = r.avg_rating;
END;

