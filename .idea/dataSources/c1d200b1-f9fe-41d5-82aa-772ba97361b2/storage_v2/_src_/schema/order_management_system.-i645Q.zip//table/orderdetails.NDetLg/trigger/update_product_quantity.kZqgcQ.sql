create definer = root@localhost trigger update_product_quantity
    after insert
    on orderdetails
    for each row
BEGIN
    DECLARE product_qty INT;
    
    -- Get the quantity of the product from the inserted order
    SELECT od.prodQuantity INTO product_qty FROM orderdetails AS od WHERE od.orderDetailId = NEW.orderDetailId;
    
    -- Update the product quantity in the products table
    UPDATE products AS p SET p.quantityAvail = p.quantityAvail - product_qty WHERE p.prodId = NEW.prodId;
END;

